#include <windows.h>
#include <tchar.h>
#include <shellapi.h>
#include <cstdio>

// ��������
const UINT MIN_TRIGGER_INTERVAL = 50; // ��С�������50ms
const UINT WM_HOTKEY_TRIGGER = WM_USER + 2;

// ȫ�ֱ���
HHOOK g_hKeyboardHook = NULL;
NOTIFYICONDATA g_notifyIconData;
HWND g_hWnd = NULL;
HANDLE g_hMutex = NULL;
bool g_bIsMuted = false;
bool g_bWindowsMinimized = false;
DWORD g_dwLastValidTriggerTime = 0;
bool g_bProcessingMessage = false;

// ��������
LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
void MinimizeAllWindows();
void RestoreWindows();
bool ToggleMute();
void CreateTrayIcon();
void RemoveTrayIcon();
void ExecuteHotkeyAction();
BOOL IsAlreadyRunning();
BOOL IsUserAnAdmin();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool IsRunAsAdmin() {
    BOOL isAdmin = FALSE;
    PSID adminGroup;
    
    SID_IDENTIFIER_AUTHORITY NtAuthority = SECURITY_NT_AUTHORITY;
    if (!AllocateAndInitializeSid(&NtAuthority, 2,
        SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS,
        0, 0, 0, 0, 0, 0, &adminGroup)) {
        return false;
    }
    
    if (!CheckTokenMembership(NULL, adminGroup, &isAdmin)) {
        isAdmin = FALSE;
    }
    
    FreeSid(adminGroup);
    return isAdmin != FALSE;
}

void ElevateToAdmin() {
    CHAR path[MAX_PATH];
    if (GetModuleFileNameA(NULL, path, MAX_PATH)) {
        SHELLEXECUTEINFOA sei = { sizeof(sei) };
        sei.lpVerb = "runas";
        sei.lpFile = path;
        sei.hwnd = NULL;
        sei.nShow = SW_NORMAL;
        
        if (!ShellExecuteExA(&sei)) {
            DWORD error = GetLastError();
            if (error == ERROR_CANCELLED) {
                MessageBox(NULL, _T("���Թ���Ա�������б�����"), _T("Ȩ�޴���"), MB_ICONERROR);
            }
        }
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ������
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	if (!IsRunAsAdmin()) {
	        ElevateToAdmin();
	        return 0;
	    }
    // ����Ƿ�����ʵ������
    if (IsAlreadyRunning()) {
        MessageBox(NULL, _T("��������������"), _T("��ʾ"), MB_ICONINFORMATION);
        return 0;
    }
    // ������ԱȨ��
    if (!IsUserAnAdmin()) {
        MessageBox(NULL, _T("���Թ���Ա�������б�����"), _T("Ȩ�޴���"), MB_ICONERROR);
        return 1;
    }

    // ע�ᴰ����
    WNDCLASSEX wc = { sizeof(WNDCLASSEX) };
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.lpszClassName = _T("CtrlAltMuteWindowClass");

    if (!RegisterClassEx(&wc)) {
        MessageBox(NULL, _T("����ע��ʧ��"), _T("����"), MB_ICONERROR);
        return 1;
    }

    // ������Ϣ����
    g_hWnd = CreateWindowEx(0, wc.lpszClassName, _T("Ctrl+Alt Mute"), 0,
                            0, 0, 0, 0, NULL, NULL, hInstance, NULL);
    if (!g_hWnd) {
        MessageBox(NULL, _T("���ڴ���ʧ��"), _T("����"), MB_ICONERROR);
        return 1;
    }

    // ���ü��̹���
    g_hKeyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, LowLevelKeyboardProc, hInstance, 0);
    if (!g_hKeyboardHook) {
        MessageBox(NULL, _T("���̹��Ӱ�װʧ��"), _T("����"), MB_ICONERROR);
        return 1;
    }

    // ��������ͼ��
    CreateTrayIcon();

    // ��Ϣѭ��
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // ������Դ
    RemoveTrayIcon();
    if (g_hKeyboardHook) UnhookWindowsHookEx(g_hKeyboardHook);
    if (g_hWnd) DestroyWindow(g_hWnd);
    if (g_hMutex) {
        ReleaseMutex(g_hMutex);
        CloseHandle(g_hMutex);
    }

    return 0;
}

// ���̹��ӻص�
LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode >= HC_ACTION) {
        // ʵʱ��ⰴ��״̬
        bool bCtrlDown = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
        bool bAltDown = (GetAsyncKeyState(VK_MENU) & 0x8000) != 0;
        
        if (bCtrlDown && bAltDown) {
            DWORD dwCurrentTime = GetTickCount();
            
            if ((dwCurrentTime - g_dwLastValidTriggerTime > MIN_TRIGGER_INTERVAL) &&
                !g_bProcessingMessage) {
                g_dwLastValidTriggerTime = dwCurrentTime;
                g_bProcessingMessage = true;
                
                if (SendMessage(g_hWnd, WM_HOTKEY_TRIGGER, 0, 0) == 0) {
                    // ʧ������
                    SendMessage(g_hWnd, WM_HOTKEY_TRIGGER, 0, 0);
                }
                
                g_bProcessingMessage = false;
            }
        }
    }
    return CallNextHookEx(g_hKeyboardHook, nCode, wParam, lParam);
}

// ���ڹ���
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message) {
        case WM_COMMAND:
            if (LOWORD(wParam) == 1000) {
                PostQuitMessage(0);
            }
            break;
            
        case WM_HOTKEY_TRIGGER:
            if ((GetAsyncKeyState(VK_CONTROL) & 0x8000) && 
                (GetAsyncKeyState(VK_MENU) & 0x8000)) {
                ExecuteHotkeyAction();
            }
            return 0;
            
        case WM_USER + 1: // ������Ϣ
            if (lParam == WM_RBUTTONUP) {
                POINT pt;
                GetCursorPos(&pt);
                
                HMENU hMenu = CreatePopupMenu();
                AppendMenu(hMenu, MF_STRING, 1000, _T("�˳�"));
                
                SetForegroundWindow(hWnd);
                TrackPopupMenu(hMenu, TPM_BOTTOMALIGN | TPM_LEFTALIGN, 
                               pt.x, pt.y, 0, hWnd, NULL);
                DestroyMenu(hMenu);
            }
            break;
            
        case WM_DESTROY:
            PostQuitMessage(0);
            break;
            
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// ִ���ȼ�����
void ExecuteHotkeyAction()
{
    if (g_bWindowsMinimized) {
        RestoreWindows();
    } else {
        MinimizeAllWindows();
    }
    ToggleMute();
}

// ��С�����д���
void MinimizeAllWindows()
{
    system("powershell -command \"(New-Object -ComObject Shell.Application).MinimizeAll()\"");
    g_bWindowsMinimized = true;
    _tcscpy(g_notifyIconData.szTip, _T("Ctrl+Alt Mute (����С��)"));
    Shell_NotifyIcon(NIM_MODIFY, &g_notifyIconData);
}

// �ָ�����
void RestoreWindows()
{
    system("powershell -command \"(New-Object -ComObject Shell.Application).UndoMinimizeALL()\"");
    g_bWindowsMinimized = false;
    _tcscpy(g_notifyIconData.szTip, _T("Ctrl+Alt Mute (�ѻָ�)"));
    Shell_NotifyIcon(NIM_MODIFY, &g_notifyIconData);
}

// �л�����״̬
bool ToggleMute()
{
    if (g_bIsMuted) {
        system("nircmd.exe mutesysvolume 0");
        _tcscpy(g_notifyIconData.szTip, _T("Ctrl+Alt Mute (��������)"));
    } else {
        system("nircmd.exe mutesysvolume 1");
        _tcscpy(g_notifyIconData.szTip, _T("Ctrl+Alt Mute (�Ѿ���)"));
    }
    
    Shell_NotifyIcon(NIM_MODIFY, &g_notifyIconData);
    g_bIsMuted = !g_bIsMuted;
    return true;
}

// ��������ͼ��
void CreateTrayIcon()
{
    ZeroMemory(&g_notifyIconData, sizeof(NOTIFYICONDATA));
    g_notifyIconData.cbSize = sizeof(NOTIFYICONDATA);
    g_notifyIconData.hWnd = g_hWnd;
    g_notifyIconData.uID = 1;
    g_notifyIconData.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    g_notifyIconData.uCallbackMessage = WM_USER + 1;
    g_notifyIconData.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    _tcscpy(g_notifyIconData.szTip, _T("Ctrl+Alt Mute"));
    
    Shell_NotifyIcon(NIM_ADD, &g_notifyIconData);
}

// �Ƴ�����ͼ��
void RemoveTrayIcon()
{
    Shell_NotifyIcon(NIM_DELETE, &g_notifyIconData);
}

// ����Ƿ�����ʵ������
BOOL IsAlreadyRunning()
{
    g_hMutex = CreateMutex(NULL, TRUE, _T("CtrlAltMute_InstanceMutex"));
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        return TRUE;
    }
    return FALSE;
}

// ������ԱȨ��
BOOL IsUserAnAdmin()
{
    BOOL b;
    SID_IDENTIFIER_AUTHORITY NtAuthority = SECURITY_NT_AUTHORITY;
    PSID AdministratorsGroup;
    
    b = AllocateAndInitializeSid(
        &NtAuthority,
        2,
        SECURITY_BUILTIN_DOMAIN_RID,
        DOMAIN_ALIAS_RID_ADMINS,
        0, 0, 0, 0, 0, 0,
        &AdministratorsGroup);
    
    if (b) {
        if (!CheckTokenMembership(NULL, AdministratorsGroup, &b)) {
            b = FALSE;
        }
        FreeSid(AdministratorsGroup);
    }
    
    return b;
}
