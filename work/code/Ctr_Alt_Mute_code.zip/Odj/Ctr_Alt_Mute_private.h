/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef CTR_ALT_MUTE_PRIVATE_H
#define CTR_ALT_MUTE_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.0.0"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	0
#define VER_BUILD	0
#define COMPANY_NAME	"��������"
#define FILE_VERSION	"1.0.0.0"
#define FILE_DESCRIPTION	"Ctr_Alt_Mute"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"KS-GWL��Ȩ���� (C) 2025"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"CAM.exe"
#define PRODUCT_NAME	"Ctr_Alt_Mute"
#define PRODUCT_VERSION	"1.0.0.0"

#endif /*CTR_ALT_MUTE_PRIVATE_H*/
