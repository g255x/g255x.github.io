﻿<?php
session_start();

// 清除会话信息
$_SESSION = [];
session_destroy();

// 重定向到登录页面
header('Location: login.php');
exit;