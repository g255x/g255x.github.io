﻿<?php
session_start();

// 检查是否登录
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 获取文件夹路径
$folderPath = isset($_GET['folder']) ? urldecode($_GET['folder']) : './sj/';

// 获取要删除的文件名
if (isset($_POST['filename'])) {
    $filename = basename($_POST['filename']); // 使用 basename 防止路径注入
    $filePath = $folderPath . '/' . $filename;

    // 检查文件是否存在
    if (file_exists($filePath)) {
        if (unlink($filePath)) {
            // 文件删除成功，返回成功信息
            header('Location: ' . $_SERVER['HTTP_REFERER']);
            exit;
        } else {
            echo "无法删除文件：$filename";
        }
    } else {
        echo "文件不存在：$filename";
    }
} else {
    echo "未指定要删除的文件。";
}
?>