﻿<?php
session_start();

// 用户凭据（存储哈希值）
$users = [
    'gwl' => '$argon2id$v=19$m=1024,t=2,p=2$M0VucXFITVIub1hlY2VXSA$jUUliMjOTUukAc3y0gYcDZzYt2fgRfjVxKZj4AmMiFQ'
];

// 获取当前用户的 IP 地址
function getUserIP() {
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

$ip_address = getUserIP();

// 登录尝试次数限制
$lockout_time = 600; // 锁定时长（10分钟）
$max_attempts = 5;   // 最大尝试次数

// 初始化尝试次数和时间戳
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = [];
}
if (!isset($_SESSION['lockout_time'])) {
    $_SESSION['lockout_time'] = [];
}

// 检查是否处于锁定状态
if (isset($_SESSION['login_attempts'][$ip_address]) && 
    $_SESSION['login_attempts'][$ip_address] >= $max_attempts && 
    time() - $_SESSION['lockout_time'][$ip_address] < $lockout_time) {
    $remaining_time = $lockout_time - (time() - $_SESSION['lockout_time'][$ip_address]);
    $error_message = "账户已被锁定，请等待 " . ceil($remaining_time / 60) . " 分钟后再试。";
} else {
    // 处理登录表单提交
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';

        if (isset($users[$username]) && password_verify($password, $users[$username])) {
            // 登录成功，重置尝试次数和锁定时间
            $_SESSION['logged_in'] = true;
            unset($_SESSION['login_attempts'][$ip_address]);
            unset($_SESSION['lockout_time'][$ip_address]);
            header('Location: upload.php');
            exit;
        } else {
            // 登录失败，增加尝试次数
            if (!isset($_SESSION['login_attempts'][$ip_address])) {
                $_SESSION['login_attempts'][$ip_address] = 0;
            }
            $_SESSION['login_attempts'][$ip_address]++;

            if ($_SESSION['login_attempts'][$ip_address] >= $max_attempts) {
                // 达到最大尝试次数，记录锁定时间
                $_SESSION['lockout_time'][$ip_address] = time();
            }
            $error_message = '用户名或密码错误';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="Zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录</title>
    <link rel="icon" href="./icon.ico" sizes="16x16" type="image/x-icon">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        input[type="text"], input[type="password"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #5cb85c;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #4cae4c;
        }
        .form-group {
            margin-bottom: 10px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .error-message {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>登录</h2>
        <?php if (isset($error_message)): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label for="username">用户名：</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">密码：</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">登录</button>
        </form>
    </div>
</body>
</html>