﻿<?php
session_start();

// 检查是否登录
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 默认文件夹路径
$baseFolder = './sj/';
$folderPath = $baseFolder; // 当前遍历的文件夹路径

// 获取打开的文件夹路径
if (isset($_GET['folder'])) {
    $folderName = urldecode($_GET['folder']);
    // 验证文件夹路径是否合法，防止目录遍历攻击
    $folderName = preg_replace('#\.\.#', '', $folderName); // 去除路径中的 ..
    $folderPath = $folderName;

    // 检查路径是否存在
    if (!is_dir($folderPath)) {
        echo "错误：指定的文件夹不存在。";
        exit;
    }
}

// 处理文件上传
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $files = $_FILES['file'];
    $file_count = count($files['name']);
    $error_message = '';

    for ($i = 0; $i < $file_count; $i++) {
        $filename = $files['name'][$i];
        $tmp_name = $files['tmp_name'][$i];
        $filepath = $folderPath . '/' . basename($filename);

        if (move_uploaded_file($tmp_name, $filepath)) {
            // 文件上传成功，继续处理下一个文件
        } else {
            $error_message .= "文件 {$filename} 上传失败<br>";
        }
    }

    if (empty($error_message)) {
        // 所有文件上传成功，刷新页面以更新文件列表
        header('Location: ' . $_SERVER['PHP_SELF'] . '?folder=' . urlencode($folderPath));
        exit;
    }
}

// 获取文件列表
function getFileList($folder)
{
    $files = [];
    if ($handle = opendir($folder)) {
        while (false !== ($entry = readdir($handle))) {
            if ($entry !== "." && $entry !== "..") {
                $files[] = $entry;
            }
        }
        closedir($handle);
    }
    return $files;
}

$files = getFileList($folderPath);
?>
<!DOCTYPE html>
<html lang="Zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="./icon.ico" sizes="16x16" type="image/x-icon">
    <title>文件上传</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0; /* 设置灰色背景 */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            position: relative; /* 相对定位，以便绝对定位注销按钮 */
        }
        .container {
            display: flex;
            width: 80%;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .sidebar {
            flex: 1;
            padding: 20px;
            border-right: 1px solid #ddd;
        }
        .content {
            flex: 3;
            padding: 20px;
            overflow-y: auto; /* 允许内容区域垂直滚动 */
            max-height: 500px; /* 设置内容区域的最大高度 */
        }
        .form-group {
            margin-bottom: 10px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="file"], input[type="text"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #5cb85c;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #4cae4c;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse; /* 移除单元格间距 */
        }
        th, td {
            padding: 10px;
            text-align: left; /* 左对齐文本 */
            border-bottom: 1px solid #ddd; /* 单元格底部边框 */
        }
        .logout-button {
            position: absolute; /* 绝对定位 */
            top: 20px; /* 距离顶部20px */
            right: 20px; /* 距离右侧20px */
            width: 30px; /* 设置宽度 */
            height: 30px; /* 设置高度 */
            background-color: #d9534f;
            color: white;
            border: none;
            border-radius: 50%; /* 设置圆角为50%，使按钮成为圆形 */
            cursor: pointer;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 14px; /* 调整字体大小 */
        }
        .logout-button:hover {
            background-color: #c9302c;
        }
        .open-folder-button {
            background-color: #5bc0de; /* 蓝色背景 */
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            padding: 5px 10px;
            text-decoration: none;
        }
        .open-folder-button:hover {
            background-color: #31b0d5;
        }
        .action-buttons {
            display: flex;
            align-items: center; /* 垂直居中对齐 */
            gap: 5px;
        }
        a {
            display: inline-block;
            text-align: center;
            color: #5cb85c;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
        }
        a:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>文件上传</h2>
            <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="file">选择文件：</label>
                    <input type="file" id="file" name="file[]" multiple> <!-- 修改此处 -->
                </div>
                <button type="submit">上传</button>
            </form>
        </div>
        <div class="content">
            <h2>文件列表</h2>
            <table>
                <tr>
                    <th>文件名</th>
                    <th>上传日期</th>
                    <th>操作</th>
                </tr>
                <?php foreach ($files as $file): ?>
                <tr id="file-<?php echo urlencode($file); ?>">
                    <td><?php echo htmlspecialchars($file); ?></td>
                    <td><?php echo date('Y-m-d', filemtime($folderPath . '/' . $file)); ?></td>
                    <td class="action-buttons">
    <?php if (is_dir($folderPath . '/' . $file)): ?>
        <!-- 如果是文件夹，显示“打开文件夹”按钮 -->
        <a href="?folder=<?php echo urlencode($folderPath . '/' . $file); ?>" class="open-folder-button">打开文件夹</a>
    <?php else: ?>
        <!-- 如果是文件，显示“下载”和“删除”按钮 -->
        <a href="<?php echo htmlspecialchars($folderPath . '/' . $file); ?>">下载</a>
        <form method="post" action="delete.php?folder=<?php echo urlencode($folderPath); ?>" style="display:inline;">
            <input type="hidden" name="filename" value="<?php echo htmlspecialchars($file); ?>">
            <button type="submit">删除</button>
        </form>
    <?php endif; ?>
</td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
    <button class="logout-button" onclick="location.href='logout.php'">注销</button>
</body>
</html>